import React from 'react';

const SPLogo = ({ className = "h-8 w-8" }: { className?: string }) => {
  return (
    <svg 
      viewBox="0 0 100 100" 
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Shield background with gradient */}
      <path
        d="M50 5 L90 20 L90 45 C90 65 73 83 50 95 C27 83 10 65 10 45 L10 20 L50 5Z"
        fill="url(#gradient)"
        stroke="white"
        strokeWidth="2"
        className="animate-pulse"
      />
      
      {/* Profile silhouette */}
      <path
        d="M50 30 C45 30 40 35 40 40 C40 45 45 50 50 50 C55 50 60 45 60 40 C60 35 55 30 50 30 Z
           M35 65 C35 55 45 50 50 50 C55 50 65 55 65 65 C65 75 55 75 50 75 C45 75 35 75 35 65"
        fill="white"
        className="animate-bounce"
      />

      {/* Animated gradient */}
      <defs>
        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#630e72">
            <animate
              attributeName="offset"
              values="0;1;0"
              dur="3s"
              repeatCount="indefinite"
            />
          </stop>
          <stop offset="100%" stopColor="#4a0b56">
            <animate
              attributeName="offset"
              values="1;2;1"
              dur="3s"
              repeatCount="indefinite"
            />
          </stop>
        </linearGradient>
      </defs>

      {/* Animated particles */}
      <circle cx="20" cy="40" r="2" fill="white" opacity="0.5">
        <animate
          attributeName="opacity"
          values="0.5;1;0.5"
          dur="2s"
          repeatCount="indefinite"
        />
      </circle>
      <circle cx="80" cy="40" r="2" fill="white" opacity="0.5">
        <animate
          attributeName="opacity"
          values="0.5;1;0.5"
          dur="2s"
          repeatCount="indefinite"
          begin="1s"
        />
      </circle>
      <circle cx="50" cy="80" r="2" fill="white" opacity="0.5">
        <animate
          attributeName="opacity"
          values="0.5;1;0.5"
          dur="2s"
          repeatCount="indefinite"
          begin="0.5s"
        />
      </circle>
    </svg>
  );
};

export default SPLogo;
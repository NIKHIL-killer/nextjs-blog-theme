import React, { useState } from 'react';
import { Activity, Battery, Wifi, Heart, Bell, Smartphone, MapPin, Clock, CheckCircle, Star, Download, Store, AlertTriangle, MapPinned, PhoneCall, Users, Shield, BookOpen, MessageCircle, Mail, Phone } from 'lucide-react';
import SPLogo from './components/SPLogo';

function App() {
  const [deviceStatus] = useState({
    batteryLevel: 85,
    connected: true,
    heartRate: 72,
    lastSync: '2 mins ago',
    location: 'Active',
  });

  const testimonials = [
    {
      name: "Priya Sharma",
      role: "College Student",
      content: "SP Band gives me confidence during my late-night study sessions at the library. The silent alarm feature is brilliant - just knowing I can alert my family without drawing attention makes me feel secure.",
      rating: 5
    },
    {
      name: "Lisa Chen",
      role: "Working Professional",
      content: "As someone who often travels alone for work, SP Band's GPS tracking and emergency contact system has been invaluable. The impact detection feature already helped me during a concerning situation.",
      rating: 5
    },
    {
      name: "Maria Rodriguez",
      role: "Safety Advocate",
      content: "I recommend SP Band to all women in our community safety program. The quick emergency response and geofencing features have already helped prevent several dangerous situations.",
      rating: 5
    }
  ];

  const coreFeatures = [
    {
      icon: AlertTriangle,
      title: "Panic Button",
      description: "Quick press for immediate emergency action"
    },
    {
      icon: MapPinned,
      title: "GPS Tracking",
      description: "Real-time location updates via companion app"
    },
    {
      icon: Bell,
      title: "Silent Alarm Mode",
      description: "Long press (5 sec) secretly sends alerts without sound"
    },
    {
      icon: Shield,
      title: "Impact Detection",
      description: "Auto-detects falls, hits, or struggles using sensors"
    },
    {
      icon: MapPin,
      title: "Safe Zones & Alerts",
      description: "Set geofences; auto check-ins when entering/exiting zones"
    },
    {
      icon: PhoneCall,
      title: "Emergency Call Loop",
      description: "Double press auto-dials 5 saved contacts"
    },
    {
      icon: Users,
      title: "5 Emergency Contacts",
      description: "Pre-save trusted contacts for instant alerts"
    },
    {
      icon: Smartphone,
      title: "Companion App",
      description: "Manage settings, track locations, and customize alerts"
    }
  ];

  const blogPosts = [
    {
      title: "Essential Self-Defense Tips for Women",
      excerpt: "Learn practical self-defense techniques and strategies...",
      author: "Safety Expert Sarah",
      date: "March 15, 2025"
    },
    {
      title: "How SP BAND Prevents Real-Life Threats",
      excerpt: "Real stories of how SP BAND's features helped in emergencies...",
      author: "Security Analyst Mike",
      date: "March 10, 2025"
    },
    {
      title: "Setting Up Your Safe Zones Effectively",
      excerpt: "A comprehensive guide to utilizing SP BAND's geofencing...",
      author: "Tech Guide Team",
      date: "March 5, 2025"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white">
      {/* Header */}
      <div className="fixed w-full top-4 z-50 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="bg-[#A230ED] rounded-2xl shadow-lg backdrop-blur-sm bg-opacity-95">
            <div className="px-6 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <SPLogo className="h-8 w-8" />
                  <h1 className="ml-3 text-2xl font-bold text-white">Smart Protection Band</h1>
                </div>
                <div className="flex items-center space-x-4">
                  <div className={`flex items-center ${deviceStatus.connected ? 'text-white' : 'text-red-300'}`}>
                    <Wifi className="h-5 w-5" />
                    <span className="ml-2 text-sm font-medium">{deviceStatus.connected ? 'Connected' : 'Disconnected'}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative bg-[#630e72] text-white py-20 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Your Personal Safety Companion</h1>
              <p className="text-lg mb-8 text-purple-100">Experience instant SOS alerts, live tracking & emergency response with our innovative safety wearable.</p>
              <div className="flex flex-wrap gap-4">
                <button className="flex items-center bg-white text-[#630e72] px-6 py-3 rounded-lg font-semibold hover:bg-purple-50 transition-colors">
                  <Store className="h-5 w-5 mr-2" />
                  Buy Now
                </button>
                <button className="flex items-center bg-white text-[#630e72] px-6 py-3 rounded-lg font-semibold hover:bg-purple-50 transition-colors">
                  <Download className="h-5 w-5 mr-2" />
                  Download App
                </button>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1510017803434-a899398421b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                alt="Smart Protection Band on wrist"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">About SP BAND</h2>
              <div className="prose prose-lg">
                <p className="text-gray-600 mb-4">
                  Founded by Nikhil Bharagav, SP BAND was born from a vision to create a powerful yet simple safety solution for women, students, and professionals.
                </p>
                <p className="text-gray-600 mb-4">
                  In today's world, personal safety shouldn't be a luxury. Our innovative wearable technology combines cutting-edge features with ease of use, ensuring help is always just a touch away.
                </p>
                <p className="text-gray-600">
                  The SP BAND system consists of a sleek wristband device paired with a powerful mobile app, creating a comprehensive safety network that connects you with emergency services and trusted contacts instantly.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-purple-50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">24/7 Protection</h3>
                <p className="text-gray-600">Always-on monitoring and instant emergency response</p>
              </div>
              <div className="bg-purple-50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Global Network</h3>
                <p className="text-gray-600">Connected to emergency services worldwide</p>
              </div>
              <div className="bg-purple-50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Easy to Use</h3>
                <p className="text-gray-600">Simple, intuitive controls for quick action</p>
              </div>
              <div className="bg-purple-50 p-6 rounded-lg">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Battery Life</h3>
                <p className="text-gray-600">Long-lasting power for reliable protection</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gradient-to-b from-purple-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">How SP BAND Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-sm text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="h-8 w-8 text-[#630e72]" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Step 1</h3>
              <p className="text-gray-600">Press the SOS button on your SP BAND</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-[#630e72]" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Step 2</h3>
              <p className="text-gray-600">Contacts receive SOS alert with your location</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Bell className="h-8 w-8 text-[#630e72]" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Step 3</h3>
              <p className="text-gray-600">Optional loud siren activates for attention</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-[#630e72]" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Step 4</h3>
              <p className="text-gray-600">Help arrives to ensure your safety</p>
            </div>
          </div>
        </div>
      </section>

      {/* Core Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Core Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {coreFeatures.map((feature, index) => (
              <div key={index} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-all">
                <feature.icon className="h-12 w-12 text-[#630e72] mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-gradient-to-b from-purple-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-all">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">{testimonial.content}</p>
                <div className="flex items-center">
                  <div>
                    <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Safety Awareness Blog</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <div key={index} className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{post.title}</h3>
                  <p className="text-gray-600 mb-4">{post.excerpt}</p>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>{post.author}</span>
                    <span>{post.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gradient-to-b from-purple-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Contact & Support</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <MessageCircle className="h-8 w-8 text-[#630e72] mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Live Chat</h3>
              <p className="text-gray-600">24/7 customer support chat available</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-6">
              <Mail className="h-8 w-8 text-[#630e72] mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Email Support</h3>
              <p className="text-gray-600">support@spband.com</p>
            </div>
            <div className="bg-white rounded-xl shadow-sm p-6">
              <Phone className="h-8 w-8 text-[#630e72] mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Phone</h3>
              <p className="text-gray-600">1-800-SP-BAND</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#630e72] text-white rounded-2xl p-12 mx-4 my-16">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-lg text-purple-100 mb-8">Take control of your safety today with SP BAND.</p>
          <div className="flex justify-center gap-4">
            <button className="flex items-center bg-white text-[#630e72] px-6 py-3 rounded-lg font-semibold hover:bg-purple-50 transition-colors">
              <Store className="h-5 w-5 mr-2" />
              Buy Now
            </button>
            <button className="flex items-center bg-white text-[#630e72] px-6 py-3 rounded-lg font-semibold hover:bg-purple-50 transition-colors">
              <Download className="h-5 w-5 mr-2" />
              Download App
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <SPLogo className="h-6 w-6" />
                <span className="ml-2 font-semibold">SP Band</span>
              </div>
              <p className="text-gray-600">Empowering safety and peace of mind through innovative technology.</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-600">
                <li>Features</li>
                <li>Pricing</li>
                <li>Support</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-600">
                <li>About Us</li>
                <li>Contact</li>
                <li>Privacy Policy</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Connect</h3>
              <ul className="space-y-2 text-gray-600">
                <li>Twitter</li>
                <li>Facebook</li>
                <li>Instagram</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-200 mt-8 pt-8 text-center text-gray-600">
            <p>&copy; 2025 SP Band. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;